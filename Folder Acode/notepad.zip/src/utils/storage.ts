import { Note, EditorSettings, NoteStats } from '../types';

const NOTES_STORAGE_KEY = 'quick_notepad_notes_v1';
const SETTINGS_STORAGE_KEY = 'quick_notepad_settings_v1';
const ACTIVE_NOTE_ID_KEY = 'quick_notepad_active_id_v1';

export const DEFAULT_SETTINGS: EditorSettings = {
  theme: 'paper',
  fontFamily: 'sans',
  fontSize: 'base',
  paperStyle: 'lined',
  lineNumbers: false,
  spellCheck: true,
  wordWrap: true,
};

export const INITIAL_NOTES: Note[] = [
  {
    id: 'welcome-note-1',
    title: 'Welcome to Notepad',
    content: `# Welcome to your clean, personal Notepad! 📝

This is a fast, distraction-free writing space designed for your thoughts, drafts, meeting notes, and to-do lists.

### ✨ What you can do:
- ✍️ **Type freely**: Changes are automatically saved in your browser as you type.
- 📌 **Pin key notes**: Keep your most important documents right at the top of the sidebar.
- 🗂️ **Categories**: Organize your thoughts with categories like Work, Ideas, and To-Do.
- 🎨 **Stationery Themes**: Switch between Warm Paper, Classic Light, Dark Mode, or Yellow Legal Pad.
- 📏 **Paper Styles**: Choose between Lined notebook, Clean plain, or subtle Graph Grid.
- 📥 **Export & Share**: Download your notes as .txt or .md files, or copy with one click.
- 📂 **Import Files**: Drag and drop or open existing .txt or .md files directly into the editor.

### ⌨️ Useful Keyboard Shortcuts:
- **Ctrl/Cmd + N**: Create a new note
- **Ctrl/Cmd + S**: Instant save (even though it auto-saves!)
- **Ctrl/Cmd + B**: Bold text
- **Ctrl/Cmd + I**: Italic text
- **Tab**: Insert indent / tab space

Happy writing!`,
    isPinned: true,
    category: 'General',
    createdAt: Date.now() - 3600000 * 2,
    updatedAt: Date.now() - 3600000,
  },
  {
    id: 'sample-todo-2',
    title: 'Quick Checklist & Ideas',
    content: `Things to accomplish this week:

[ ] Review project architecture & design specs
[x] Send weekly progress report
[ ] Prepare talking points for client catch-up
[ ] Pick up groceries & fresh coffee beans
[ ] Schedule 30 min focus session for creative brainstorming

💡 Inspiring ideas for the month:
- Minimalist desk layout
- New book recommendation: Designing Data-Intensive Applications
- Try making sourdough starter this weekend`,
    isPinned: false,
    category: 'To-Do',
    createdAt: Date.now() - 7200000,
    updatedAt: Date.now() - 7200000,
  },
];

export function loadNotes(): Note[] {
  try {
    const data = localStorage.getItem(NOTES_STORAGE_KEY);
    if (!data) return INITIAL_NOTES;
    const parsed = JSON.parse(data);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return INITIAL_NOTES;
  } catch (e) {
    console.error('Error loading notes from localStorage:', e);
    return INITIAL_NOTES;
  }
}

export function saveNotes(notes: Note[]): void {
  try {
    localStorage.setItem(NOTES_STORAGE_KEY, JSON.stringify(notes));
  } catch (e) {
    console.error('Error saving notes to localStorage:', e);
  }
}

export function loadActiveNoteId(notes: Note[]): string {
  try {
    const stored = localStorage.getItem(ACTIVE_NOTE_ID_KEY);
    if (stored && notes.some(n => n.id === stored)) {
      return stored;
    }
  } catch {
    // Ignore
  }
  return notes[0]?.id || '';
}

export function saveActiveNoteId(id: string): void {
  try {
    localStorage.setItem(ACTIVE_NOTE_ID_KEY, id);
  } catch {
    // Ignore
  }
}

export function loadSettings(): EditorSettings {
  try {
    const data = localStorage.getItem(SETTINGS_STORAGE_KEY);
    if (!data) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(data) };
  } catch (e) {
    console.error('Error loading settings:', e);
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: EditorSettings): void {
  try {
    localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error('Error saving settings:', e);
  }
}

export function calculateStats(text: string): NoteStats {
  if (!text) {
    return {
      words: 0,
      characters: 0,
      charactersNoSpaces: 0,
      lines: 1,
      readingTimeMinutes: 0,
    };
  }

  const characters = text.length;
  const charactersNoSpaces = text.replace(/\s/g, '').length;
  const words = text.trim() ? text.trim().split(/\s+/).filter(Boolean).length : 0;
  const lines = text.split('\n').length;
  const readingTimeMinutes = Math.max(1, Math.ceil(words / 200));

  return {
    words,
    characters,
    charactersNoSpaces,
    lines,
    readingTimeMinutes,
  };
}

export function downloadFile(filename: string, content: string, type: string = 'text/plain;charset=utf-8'): void {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  URL.revokeObjectURL(url);
}

export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    } else {
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      const successful = document.execCommand('copy');
      document.body.removeChild(textArea);
      return successful;
    }
  } catch (e) {
    console.error('Copy failed', e);
    return false;
  }
}

export function formatDate(timestamp: number): string {
  const date = new Date(timestamp);
  const now = new Date();
  const diffHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60);

  if (diffHours < 24 && now.getDate() === date.getDate()) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
  if (diffHours < 48 && now.getDate() - date.getDate() === 1) {
    return 'Yesterday';
  }
  return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
}
