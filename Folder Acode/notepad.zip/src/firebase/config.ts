import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';

export const firebaseConfig = {
  apiKey: "AIzaSyADLJW6p_H4BiYaPS8Yx4HhqFGEda9z9tw",
  authDomain: "testing-project-b88c4.firebaseapp.com",
  databaseURL: "https://testing-project-b88c4-default-rtdb.firebaseio.com",
  projectId: "testing-project-b88c4",
  storageBucket: "testing-project-b88c4.firebasestorage.app",
  messagingSenderId: "277304232672",
  appId: "1:277304232672:web:a00bf74f956836b5bade85"
};

// Initialize Firebase safely
export const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);
export const db = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

// Test connection on boot per Firebase guidelines
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase connection check: Client offline or unreachable.');
    }
    return false;
  }
}

testConnection();
