export type ThemeMode = 'paper' | 'light' | 'dark' | 'amber';
export type FontFamily = 'sans' | 'serif' | 'mono';
export type FontSize = 'sm' | 'base' | 'lg' | 'xl';
export type PaperStyle = 'plain' | 'lined' | 'grid';

export interface Note {
  id: string;
  userId?: string;
  title: string;
  content: string;
  isPinned: boolean;
  category: string;
  createdAt: number;
  updatedAt: number;
}

export interface EditorSettings {
  theme: ThemeMode;
  fontFamily: FontFamily;
  fontSize: FontSize;
  paperStyle: PaperStyle;
  lineNumbers: boolean;
  spellCheck: boolean;
  wordWrap: boolean;
}

export interface NoteStats {
  words: number;
  characters: number;
  charactersNoSpaces: number;
  lines: number;
  readingTimeMinutes: number;
}
