import React from 'react';
import { X, Clock, FileText, AlignLeft, Calendar } from 'lucide-react';
import { Note, NoteStats } from '../types';

interface StatsModalProps {
  isOpen: boolean;
  onClose: () => void;
  stats: NoteStats;
  activeNote: Note | null;
}

export const StatsModal: React.FC<StatsModalProps> = ({
  isOpen,
  onClose,
  stats,
  activeNote,
}) => {
  if (!isOpen) return null;

  const speakingTimeMinutes = Math.max(1, Math.ceil(stats.words / 130));

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs select-none"
      onClick={onClose}
    >
      <div 
        id="stats-modal"
        className="w-full max-w-sm rounded-xl bg-white dark:bg-neutral-900 shadow-xl border border-neutral-200 dark:border-neutral-800 p-5 text-neutral-800 dark:text-neutral-100"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-amber-500" />
            <h3 className="text-sm font-semibold">Note Statistics</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 py-4">
          <div className="p-3 rounded-lg bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-100 dark:border-neutral-800 text-center">
            <span className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-50">
              {stats.words.toLocaleString()}
            </span>
            <span className="block text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
              Words
            </span>
          </div>

          <div className="p-3 rounded-lg bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-100 dark:border-neutral-800 text-center">
            <span className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-neutral-50">
              {stats.characters.toLocaleString()}
            </span>
            <span className="block text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
              Characters
            </span>
          </div>

          <div className="p-3 rounded-lg bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-100 dark:border-neutral-800 text-center">
            <span className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-50">
              {stats.charactersNoSpaces.toLocaleString()}
            </span>
            <span className="block text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
              Without Spaces
            </span>
          </div>

          <div className="p-3 rounded-lg bg-neutral-50 dark:bg-neutral-800/60 border border-neutral-100 dark:border-neutral-800 text-center">
            <span className="text-xl font-bold tracking-tight text-neutral-900 dark:text-neutral-50">
              {stats.lines.toLocaleString()}
            </span>
            <span className="block text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
              Lines
            </span>
          </div>
        </div>

        <div className="space-y-2 pt-2 border-t border-neutral-100 dark:border-neutral-800 text-xs text-neutral-600 dark:text-neutral-300">
          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 opacity-60" />
              Reading Time
            </span>
            <span className="font-medium">~{stats.readingTimeMinutes} min</span>
          </div>

          <div className="flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <AlignLeft className="w-3.5 h-3.5 opacity-60" />
              Speaking Time
            </span>
            <span className="font-medium">~{speakingTimeMinutes} min</span>
          </div>

          {activeNote && (
            <div className="flex items-center justify-between pt-1 text-[11px] text-neutral-400">
              <span className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 opacity-60" />
                Last Modified
              </span>
              <span>{new Date(activeNote.updatedAt).toLocaleString()}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
