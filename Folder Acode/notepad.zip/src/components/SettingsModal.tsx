import React from 'react';
import { X, Palette, Type, Sliders, Keyboard } from 'lucide-react';
import { EditorSettings, ThemeMode, FontFamily, FontSize, PaperStyle } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: EditorSettings;
  onUpdateSettings: (settings: Partial<EditorSettings>) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  if (!isOpen) return null;

  const themes: { id: ThemeMode; label: string; icon: string; previewClass: string }[] = [
    { id: 'paper', label: 'Warm Paper', icon: '📜', previewClass: 'bg-[#fbf8f2] text-[#2c2825] border-[#e8ded1]' },
    { id: 'light', label: 'Crisp Light', icon: '☀️', previewClass: 'bg-white text-slate-800 border-slate-200' },
    { id: 'dark', label: 'Dark Slate', icon: '🌙', previewClass: 'bg-[#18181b] text-[#f4f4f5] border-[#27272a]' },
    { id: 'amber', label: 'Legal Pad', icon: '📒', previewClass: 'bg-[#fef9c3] text-[#292524] border-[#fde047]' },
  ];

  const paperStyles: { id: PaperStyle; label: string }[] = [
    { id: 'lined', label: 'Lined Notebook' },
    { id: 'grid', label: 'Dot Grid' },
    { id: 'plain', label: 'Plain Sheet' },
  ];

  const fonts: { id: FontFamily; label: string; style: string }[] = [
    { id: 'sans', label: 'Modern Sans', style: 'font-sans' },
    { id: 'serif', label: 'Editorial Serif', style: 'font-serif' },
    { id: 'mono', label: 'Code Mono', style: 'font-mono' },
  ];

  const fontSizes: { id: FontSize; label: string; px: string }[] = [
    { id: 'sm', label: 'Small', px: '14px' },
    { id: 'base', label: 'Medium', px: '16px' },
    { id: 'lg', label: 'Large', px: '18px' },
    { id: 'xl', label: 'X-Large', px: '20px' },
  ];

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs select-none"
      onClick={onClose}
    >
      <div 
        id="settings-modal"
        className="w-full max-w-md rounded-xl bg-white dark:bg-neutral-900 shadow-xl border border-neutral-200 dark:border-neutral-800 p-5 text-neutral-800 dark:text-neutral-100 max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 border-b border-neutral-100 dark:border-neutral-800">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-500" />
            <h3 className="text-sm font-semibold">Notepad Appearance</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-4 py-4 text-xs">
          {/* Theme Mode */}
          <div>
            <label className="flex items-center gap-1.5 font-medium text-neutral-700 dark:text-neutral-300 mb-2">
              <Palette className="w-3.5 h-3.5" />
              <span>Theme Canvas</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              {themes.map((t) => (
                <button
                  key={t.id}
                  onClick={() => onUpdateSettings({ theme: t.id })}
                  className={`p-2.5 rounded-lg border text-left flex items-center gap-2 transition-all cursor-pointer ${
                    t.previewClass
                  } ${
                    settings.theme === t.id 
                      ? 'ring-2 ring-neutral-900 dark:ring-white font-medium shadow-xs' 
                      : 'opacity-80 hover:opacity-100'
                  }`}
                >
                  <span className="text-sm">{t.icon}</span>
                  <span className="text-xs truncate">{t.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Paper Texture */}
          <div>
            <label className="font-medium text-neutral-700 dark:text-neutral-300 mb-2 block">
              Paper Texture
            </label>
            <div className="grid grid-cols-3 gap-2">
              {paperStyles.map((ps) => (
                <button
                  key={ps.id}
                  onClick={() => onUpdateSettings({ paperStyle: ps.id })}
                  className={`py-2 px-2.5 rounded-lg border text-center transition-colors cursor-pointer text-xs ${
                    settings.paperStyle === ps.id
                      ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 font-medium'
                      : 'border-neutral-200 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                  }`}
                >
                  {ps.label}
                </button>
              ))}
            </div>
          </div>

          {/* Font Family */}
          <div>
            <label className="flex items-center gap-1.5 font-medium text-neutral-700 dark:text-neutral-300 mb-2">
              <Type className="w-3.5 h-3.5" />
              <span>Typography</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              {fonts.map((f) => (
                <button
                  key={f.id}
                  onClick={() => onUpdateSettings({ fontFamily: f.id })}
                  className={`py-2 px-2 rounded-lg border text-center transition-colors cursor-pointer text-xs ${
                    settings.fontFamily === f.id
                      ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 font-medium'
                      : 'border-neutral-200 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                  }`}
                >
                  <span style={{ 
                    fontFamily: f.id === 'serif' ? 'var(--notepad-font-serif)' : f.id === 'mono' ? 'var(--notepad-font-mono)' : 'var(--notepad-font-sans)' 
                  }}>
                    {f.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Font Size */}
          <div>
            <label className="font-medium text-neutral-700 dark:text-neutral-300 mb-2 block">
              Font Size
            </label>
            <div className="grid grid-cols-4 gap-2">
              {fontSizes.map((fs) => (
                <button
                  key={fs.id}
                  onClick={() => onUpdateSettings({ fontSize: fs.id })}
                  className={`py-1.5 rounded-lg border text-center transition-colors cursor-pointer text-xs ${
                    settings.fontSize === fs.id
                      ? 'bg-neutral-900 text-white dark:bg-white dark:text-neutral-900 font-medium'
                      : 'border-neutral-200 dark:border-neutral-700 hover:bg-neutral-100 dark:hover:bg-neutral-800'
                  }`}
                >
                  {fs.label}
                </button>
              ))}
            </div>
          </div>

          {/* Editor switches */}
          <div className="space-y-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-300">Spell Check</span>
              <input
                type="checkbox"
                checked={settings.spellCheck}
                onChange={(e) => onUpdateSettings({ spellCheck: e.target.checked })}
                className="rounded border-neutral-300 text-neutral-900 focus:ring-neutral-900 cursor-pointer w-4 h-4"
              />
            </div>

            <div className="flex items-center justify-between">
              <span className="text-neutral-600 dark:text-neutral-300">Show Line Numbers</span>
              <input
                type="checkbox"
                checked={settings.lineNumbers}
                onChange={(e) => onUpdateSettings({ lineNumbers: e.target.checked })}
                className="rounded border-neutral-300 text-neutral-900 focus:ring-neutral-900 cursor-pointer w-4 h-4"
              />
            </div>
          </div>

          {/* Keyboard Shortcuts Helper */}
          <div className="pt-3 border-t border-neutral-100 dark:border-neutral-800 text-[11px] text-neutral-500">
            <div className="flex items-center gap-1 font-semibold text-neutral-700 dark:text-neutral-300 mb-2">
              <Keyboard className="w-3.5 h-3.5" />
              <span>Keyboard Shortcuts</span>
            </div>
            <div className="grid grid-cols-2 gap-x-2 gap-y-1">
              <div><kbd className="px-1 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 border">Ctrl+N</kbd> New Note</div>
              <div><kbd className="px-1 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 border">Ctrl+S</kbd> Save Note</div>
              <div><kbd className="px-1 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 border">Ctrl+B</kbd> Bold Text</div>
              <div><kbd className="px-1 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 border">Ctrl+I</kbd> Italic Text</div>
              <div><kbd className="px-1 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 border">Tab</kbd> Indent spaces</div>
              <div><kbd className="px-1 py-0.5 rounded bg-neutral-100 dark:bg-neutral-800 border">Esc</kbd> Exit Focus</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
