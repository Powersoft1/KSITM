import React, { useState } from 'react';
import { 
  FileText, 
  Plus, 
  Download, 
  Copy, 
  Check, 
  SlidersHorizontal, 
  Maximize2, 
  Minimize2, 
  BarChart2, 
  PanelLeftClose, 
  PanelLeft,
  Cloud,
  CloudOff,
  User as UserIcon,
  LogOut,
  LogIn
} from 'lucide-react';
import { EditorSettings, Note } from '../types';
import { useAuth } from '../context/AuthContext';

interface HeaderProps {
  activeNote: Note | null;
  settings: EditorSettings;
  onUpdateSettings: (settings: Partial<EditorSettings>) => void;
  onNewNote: () => void;
  onDownload: (format: 'txt' | 'md') => void;
  onCopyContent: () => void;
  isCopied: boolean;
  isSidebarOpen: boolean;
  onToggleSidebar: () => void;
  isFocusMode: boolean;
  onToggleFocusMode: () => void;
  onOpenStats: () => void;
  onOpenSettings: () => void;
  onOpenAuth: () => void;
  saveStatus: 'saved' | 'saving';
}

export const Header: React.FC<HeaderProps> = ({
  activeNote,
  onNewNote,
  onDownload,
  onCopyContent,
  isCopied,
  isSidebarOpen,
  onToggleSidebar,
  isFocusMode,
  onToggleFocusMode,
  onOpenStats,
  onOpenSettings,
  onOpenAuth,
  saveStatus,
}) => {
  const [showDownloadMenu, setShowDownloadMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const { user, signOut } = useAuth();

  return (
    <header 
      id="notepad-header"
      className="h-14 border-b flex items-center justify-between px-3 md:px-5 shrink-0 transition-colors select-none z-20"
    >
      {/* Left section: Sidebar toggle & Logo */}
      <div className="flex items-center gap-2 md:gap-3">
        {!isFocusMode && (
          <button
            id="sidebar-toggle-btn"
            onClick={onToggleSidebar}
            title={isSidebarOpen ? 'Hide Notes Sidebar' : 'Show Notes Sidebar'}
            className="p-1.5 rounded-md hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer"
          >
            {isSidebarOpen ? <PanelLeftClose className="w-5 h-5" /> : <PanelLeft className="w-5 h-5" />}
          </button>
        )}

        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-md bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center font-semibold text-sm">
            <FileText className="w-4 h-4" />
          </div>
          <span className="font-semibold tracking-tight text-neutral-800 dark:text-neutral-100 hidden sm:inline-block">
            Notepad
          </span>
        </div>

        {/* Cloud Sync & Save status */}
        <div className="ml-2 flex items-center gap-2 text-xs text-neutral-600 dark:text-neutral-400 font-medium">
          <div className="flex items-center gap-1.5" title={user ? 'Synced with Firebase Cloud Firestore' : 'Saved locally in browser'}>
            {user ? (
              <Cloud className="w-3.5 h-3.5 text-emerald-500" />
            ) : (
              <CloudOff className="w-3.5 h-3.5 text-amber-500" />
            )}
            <span className="hidden md:inline">
              {user ? (saveStatus === 'saving' ? 'Syncing...' : 'Cloud Synced') : 'Local'}
            </span>
          </div>

          <span className="text-neutral-300 dark:text-neutral-700 hidden md:inline">•</span>

          <div className="hidden sm:flex items-center gap-1.5">
            <span className={`w-1.5 h-1.5 rounded-full transition-colors ${
              saveStatus === 'saving' ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'
            }`} />
            <span className="hidden lg:inline text-[11px] text-neutral-600 dark:text-neutral-400">
              {saveStatus === 'saving' ? 'Saving...' : 'Ready'}
            </span>
          </div>
        </div>
      </div>

      {/* Center section: Note Title preview in Focus mode */}
      {isFocusMode && activeNote && (
        <div className="hidden md:block max-w-md truncate text-sm font-medium text-neutral-700 dark:text-neutral-200 text-center px-4">
          {activeNote.title || 'Untitled Note'}
        </div>
      )}

      {/* Right section: Actions */}
      <div className="flex items-center gap-1 md:gap-2">
        {/* New Note Button */}
        <button
          id="header-new-note-btn"
          onClick={onNewNote}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-neutral-900 hover:bg-neutral-800 dark:bg-neutral-100 dark:hover:bg-neutral-200 text-white dark:text-neutral-900 text-xs md:text-sm font-medium transition-all shadow-xs cursor-pointer"
          title="Create New Note (Ctrl+N)"
        >
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">New Note</span>
        </button>

        {/* Copy Note Button */}
        <button
          id="header-copy-btn"
          onClick={onCopyContent}
          disabled={!activeNote}
          title={isCopied ? 'Copied!' : 'Copy Note to Clipboard'}
          className="p-1.5 md:px-2.5 md:py-1.5 rounded-md hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 text-xs md:text-sm font-medium flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-40"
        >
          {isCopied ? (
            <>
              <Check className="w-4 h-4 text-emerald-500" />
              <span className="hidden md:inline text-emerald-600 dark:text-emerald-400">Copied</span>
            </>
          ) : (
            <>
              <Copy className="w-4 h-4" />
              <span className="hidden md:inline">Copy</span>
            </>
          )}
        </button>

        {/* Download / Export Menu */}
        <div className="relative">
          <button
            id="header-download-btn"
            onClick={() => setShowDownloadMenu(!showDownloadMenu)}
            disabled={!activeNote}
            title="Download Note"
            className="p-1.5 md:px-2.5 md:py-1.5 rounded-md hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 text-xs md:text-sm font-medium flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-40"
          >
            <Download className="w-4 h-4" />
            <span className="hidden md:inline">Export</span>
          </button>

          {showDownloadMenu && (
            <div 
              className="absolute right-0 mt-1 w-44 rounded-lg bg-white dark:bg-neutral-800 shadow-lg border border-neutral-200 dark:border-neutral-700 py-1 z-30 text-xs md:text-sm"
              onMouseLeave={() => setShowDownloadMenu(false)}
            >
              <button
                id="export-txt-btn"
                onClick={() => {
                  onDownload('txt');
                  setShowDownloadMenu(false);
                }}
                className="w-full text-left px-3 py-2 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-200 flex items-center justify-between cursor-pointer"
              >
                <span>Plain Text (.txt)</span>
                <span className="text-[10px] text-neutral-600 dark:text-neutral-400 uppercase font-mono">TXT</span>
              </button>
              <button
                id="export-md-btn"
                onClick={() => {
                  onDownload('md');
                  setShowDownloadMenu(false);
                }}
                className="w-full text-left px-3 py-2 hover:bg-neutral-100 dark:hover:bg-neutral-700 text-neutral-700 dark:text-neutral-200 flex items-center justify-between cursor-pointer"
              >
                <span>Markdown (.md)</span>
                <span className="text-[10px] text-neutral-600 dark:text-neutral-400 uppercase font-mono">MD</span>
              </button>
            </div>
          )}
        </div>

        {/* Word/Char Stats */}
        <button
          id="header-stats-btn"
          onClick={onOpenStats}
          title="Note Statistics & Reading Time"
          className="p-1.5 rounded-md hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer"
        >
          <BarChart2 className="w-4 h-4" />
        </button>

        {/* Editor Settings (Theme, Font, Paper Style) */}
        <button
          id="header-settings-btn"
          onClick={onOpenSettings}
          title="Paper & Appearance Settings"
          className="p-1.5 rounded-md hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer"
        >
          <SlidersHorizontal className="w-4 h-4" />
        </button>

        {/* Fullscreen Focus Mode */}
        <button
          id="header-focus-btn"
          onClick={onToggleFocusMode}
          title={isFocusMode ? 'Exit Focus Mode' : 'Enter Distraction-free Focus Mode'}
          className="p-1.5 rounded-md hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer"
        >
          {isFocusMode ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>

        {/* User Account / Login Button */}
        <div className="relative ml-1 pl-1 border-l border-neutral-200 dark:border-neutral-700">
          {user ? (
            <div>
              <button
                id="header-user-menu-btn"
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center gap-1.5 p-1 rounded-full hover:ring-2 hover:ring-neutral-300 dark:hover:ring-neutral-700 transition-all cursor-pointer"
                title={`Logged in as ${user.displayName || user.email || 'User'}`}
              >
                {user.photoURL ? (
                  <img 
                    src={user.photoURL} 
                    alt={user.displayName || 'User'} 
                    className="w-7 h-7 rounded-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-amber-500 text-white font-medium text-xs flex items-center justify-center">
                    {(user.displayName || user.email || 'U')[0].toUpperCase()}
                  </div>
                )}
              </button>

              {showUserMenu && (
                <div 
                  className="absolute right-0 mt-2 w-56 rounded-xl bg-white dark:bg-neutral-900 shadow-xl border border-neutral-200 dark:border-neutral-800 p-2 z-40 text-xs"
                  onMouseLeave={() => setShowUserMenu(false)}
                >
                  <div className="px-2.5 py-2 border-b border-neutral-100 dark:border-neutral-800 mb-1">
                    <p className="font-semibold truncate text-neutral-800 dark:text-neutral-100">
                      {user.displayName || 'User'}
                    </p>
                    <p className="text-[11px] text-neutral-600 dark:text-neutral-400 truncate">
                      {user.email}
                    </p>
                  </div>

                  <div className="px-2.5 py-1.5 text-[11px] text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                    <Cloud className="w-3.5 h-3.5" />
                    <span>Firebase Cloud Sync Active</span>
                  </div>

                  <button
                    id="header-signout-btn"
                    onClick={() => {
                      setShowUserMenu(false);
                      signOut();
                    }}
                    className="w-full mt-1 flex items-center gap-2 px-2.5 py-2 rounded-lg text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/40 font-medium transition-colors cursor-pointer"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              id="header-login-btn"
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-amber-500/40 bg-amber-500/10 hover:bg-amber-500/20 text-amber-700 dark:text-amber-400 text-xs font-medium transition-all cursor-pointer shadow-2xs"
              title="Sign in to sync notes across devices"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Sign In</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

