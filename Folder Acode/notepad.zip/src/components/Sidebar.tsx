import React, { useState, useMemo } from 'react';
import { 
  Search, 
  X, 
  Pin, 
  Trash2, 
  Copy, 
  Upload, 
  Plus, 
  FileText, 
  Clock, 
  Folder 
} from 'lucide-react';
import { Note } from '../types';
import { formatDate } from '../utils/storage';

interface SidebarProps {
  notes: Note[];
  activeNoteId: string;
  onSelectNote: (id: string) => void;
  onNewNote: () => void;
  onDeleteNote: (id: string) => void;
  onDuplicateNote: (id: string) => void;
  onTogglePin: (id: string) => void;
  onImportFile: (file: File) => void;
  isOpen: boolean;
  onCloseMobile: () => void;
}

const CATEGORIES = ['All', 'General', 'Work', 'Ideas', 'To-Do'];

export const Sidebar: React.FC<SidebarProps> = ({
  notes,
  activeNoteId,
  onSelectNote,
  onNewNote,
  onDeleteNote,
  onDuplicateNote,
  onTogglePin,
  onImportFile,
  isOpen,
  onCloseMobile,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const filteredNotes = useMemo(() => {
    return notes
      .filter((note) => {
        const matchesCategory =
          selectedCategory === 'All' || note.category === selectedCategory;
        const matchesSearch =
          !searchQuery.trim() ||
          note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          note.content.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesCategory && matchesSearch;
      })
      .sort((a, b) => {
        // Pinned notes first
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
        // Then by updated timestamp descending
        return b.updatedAt - a.updatedAt;
      });
  }, [notes, selectedCategory, searchQuery]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImportFile(file);
      e.target.value = '';
    }
  };

  if (!isOpen) {
    return null;
  }

  return (
    <>
      {/* Mobile backdrop */}
      <div 
        className="fixed inset-0 bg-black/30 z-30 md:hidden backdrop-blur-xs"
        onClick={onCloseMobile}
      />

      <aside
        id="notepad-sidebar"
        className="fixed md:static inset-y-0 left-0 w-72 sm:w-80 shrink-0 border-r flex flex-col z-30 transition-transform select-none bg-inherit"
      >
        {/* Top Search & Actions */}
        <div className="p-3 border-b space-y-2">
          {/* Search bar */}
          <div className="relative flex items-center">
            <Search className="w-4 h-4 absolute left-2.5 text-neutral-600 dark:text-neutral-400 pointer-events-none" />
            <input
              id="sidebar-search-input"
              type="text"
              placeholder="Search notes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-7 py-1.5 text-xs rounded-md bg-black/5 dark:bg-white/10 border-transparent focus:border-neutral-400 dark:focus:border-neutral-500 focus:outline-hidden placeholder:text-neutral-600 dark:placeholder:text-neutral-400 text-neutral-800 dark:text-neutral-100"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 no-scrollbar text-xs">
            {CATEGORIES.map((cat) => {
              const count = cat === 'All' 
                ? notes.length 
                : notes.filter(n => n.category === cat).length;
              const isSelected = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2 py-1 rounded-full whitespace-nowrap transition-colors flex items-center gap-1 cursor-pointer text-[11px] font-medium ${
                    isSelected
                      ? 'bg-neutral-800 text-white dark:bg-neutral-200 dark:text-neutral-900'
                      : 'bg-black/5 dark:bg-white/5 text-neutral-600 dark:text-neutral-400 hover:bg-black/10 dark:hover:bg-white/10'
                  }`}
                >
                  <span>{cat}</span>
                  <span className={`text-[9px] px-1 rounded-full ${
                    isSelected ? 'bg-white/20 dark:bg-black/20' : 'opacity-60'
                  }`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Notes List */}
        <div className="flex-1 overflow-y-auto px-2 py-2 space-y-1">
          {filteredNotes.length === 0 ? (
            <div className="text-center py-10 px-4 text-neutral-600 dark:text-neutral-400">
              <FileText className="w-8 h-8 mx-auto mb-2 opacity-40" />
              <p className="text-xs font-medium">No notes found</p>
              <p className="text-[11px] opacity-75 mt-0.5">
                {searchQuery ? 'Try a different search term' : 'Click "New Note" to start writing'}
              </p>
            </div>
          ) : (
            filteredNotes.map((note) => {
              const isActive = note.id === activeNoteId;
              const preview = note.content
                .replace(/^[#\s\-\*\>]+/gm, '')
                .trim()
                .slice(0, 75);

              return (
                <div
                  key={note.id}
                  id={`note-item-${note.id}`}
                  onClick={() => {
                    onSelectNote(note.id);
                    onCloseMobile();
                  }}
                  className={`group relative p-2.5 rounded-lg text-left transition-all cursor-pointer border ${
                    isActive
                      ? 'bg-black/10 dark:bg-white/15 border-neutral-300 dark:border-neutral-600 shadow-xs'
                      : 'border-transparent hover:bg-black/5 dark:hover:bg-white/5'
                  }`}
                >
                  <div className="flex items-start justify-between gap-1.5">
                    <h3 className="text-xs font-semibold text-neutral-900 dark:text-neutral-100 truncate flex-1">
                      {note.title.trim() || 'Untitled Note'}
                    </h3>
                    {note.isPinned && (
                      <Pin className="w-3.5 h-3.5 text-amber-500 fill-amber-500 shrink-0" />
                    )}
                  </div>

                  {preview && (
                    <p className="text-[11px] text-neutral-500 dark:text-neutral-400 line-clamp-2 mt-1 leading-relaxed break-words font-normal">
                      {preview}
                    </p>
                  )}

                  <div className="mt-2 flex items-center justify-between text-[10px] text-neutral-600 dark:text-neutral-400">
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3 h-3" />
                      <span>{formatDate(note.updatedAt)}</span>
                      {note.category && (
                        <span className="px-1.5 py-0.5 rounded-sm bg-black/5 dark:bg-white/10 font-medium">
                          {note.category}
                        </span>
                      )}
                    </div>

                    {/* Action buttons on hover */}
                    <div 
                      className="opacity-0 group-hover:opacity-100 focus-within:opacity-100 flex items-center gap-1 transition-opacity"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button
                        title={note.isPinned ? 'Unpin Note' : 'Pin Note to Top'}
                        onClick={() => onTogglePin(note.id)}
                        className="p-1 rounded hover:bg-black/10 dark:hover:bg-white/20 text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200 cursor-pointer"
                      >
                        <Pin className={`w-3 h-3 ${note.isPinned ? 'fill-current' : ''}`} />
                      </button>
                      <button
                        title="Duplicate Note"
                        onClick={() => onDuplicateNote(note.id)}
                        className="p-1 rounded hover:bg-black/10 dark:hover:bg-white/20 text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200 cursor-pointer"
                      >
                        <Copy className="w-3 h-3" />
                      </button>
                      <button
                        title="Delete Note"
                        onClick={() => onDeleteNote(note.id)}
                        className="p-1 rounded hover:bg-red-500/15 text-neutral-500 hover:text-red-600 dark:hover:text-red-400 cursor-pointer"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Sidebar Footer: Quick New Note & Import File */}
        <div className="p-3 border-t flex items-center justify-between gap-2 text-xs">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".txt,.md,.markdown"
            className="hidden"
          />

          <button
            id="sidebar-import-file-btn"
            onClick={() => fileInputRef.current?.click()}
            className="flex-1 py-1.5 px-2.5 rounded-md border border-dashed border-neutral-300 dark:border-neutral-700 hover:border-neutral-400 text-neutral-600 dark:text-neutral-400 hover:text-neutral-800 dark:hover:text-neutral-200 flex items-center justify-center gap-1.5 transition-colors cursor-pointer text-xs"
            title="Import text or markdown file"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Open File</span>
          </button>

          <button
            id="sidebar-new-note-quick-btn"
            onClick={onNewNote}
            className="py-1.5 px-3 rounded-md bg-neutral-800 dark:bg-neutral-200 hover:bg-neutral-700 text-white dark:text-neutral-900 font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer text-xs shadow-2xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Note</span>
          </button>
        </div>
      </aside>
    </>
  );
};
