import React from 'react';
import { 
  Bold, 
  Italic, 
  Strikethrough, 
  Heading1, 
  Heading2, 
  List, 
  ListOrdered, 
  CheckSquare, 
  Quote, 
  Code, 
  Calendar, 
  Minus, 
  Trash2 
} from 'lucide-react';

interface FormatToolbarProps {
  onInsertFormat: (prefix: string, suffix?: string, defaultPlaceholder?: string) => void;
  onClearContent: () => void;
  onInsertTimestamp: () => void;
}

export const FormatToolbar: React.FC<FormatToolbarProps> = ({
  onInsertFormat,
  onClearContent,
  onInsertTimestamp,
}) => {
  return (
    <div 
      id="notepad-format-toolbar"
      className="flex items-center gap-0.5 px-3 py-1.5 border-b overflow-x-auto text-xs no-scrollbar select-none shrink-0"
    >
      {/* Text Style Group */}
      <button
        type="button"
        title="Bold (Ctrl+B)"
        onClick={() => onInsertFormat('**', '**', 'bold text')}
        className="p-1.5 rounded hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer"
      >
        <Bold className="w-3.5 h-3.5" />
      </button>

      <button
        type="button"
        title="Italic (Ctrl+I)"
        onClick={() => onInsertFormat('*', '*', 'italic text')}
        className="p-1.5 rounded hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer"
      >
        <Italic className="w-3.5 h-3.5" />
      </button>

      <button
        type="button"
        title="Strikethrough"
        onClick={() => onInsertFormat('~~', '~~', 'strikethrough text')}
        className="p-1.5 rounded hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer"
      >
        <Strikethrough className="w-3.5 h-3.5" />
      </button>

      <div className="w-px h-4 bg-neutral-200 dark:bg-neutral-700 mx-1 shrink-0" />

      {/* Headings */}
      <button
        type="button"
        title="Heading 1"
        onClick={() => onInsertFormat('# ', '', 'Heading 1')}
        className="p-1.5 rounded hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer font-bold text-xs"
      >
        <Heading1 className="w-3.5 h-3.5" />
      </button>

      <button
        type="button"
        title="Heading 2"
        onClick={() => onInsertFormat('## ', '', 'Heading 2')}
        className="p-1.5 rounded hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer"
      >
        <Heading2 className="w-3.5 h-3.5" />
      </button>

      <div className="w-px h-4 bg-neutral-200 dark:bg-neutral-700 mx-1 shrink-0" />

      {/* Lists */}
      <button
        type="button"
        title="Bullet List"
        onClick={() => onInsertFormat('- ', '', 'List item')}
        className="p-1.5 rounded hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer"
      >
        <List className="w-3.5 h-3.5" />
      </button>

      <button
        type="button"
        title="Numbered List"
        onClick={() => onInsertFormat('1. ', '', 'Numbered item')}
        className="p-1.5 rounded hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer"
      >
        <ListOrdered className="w-3.5 h-3.5" />
      </button>

      <button
        type="button"
        title="Task Checklist [ ]"
        onClick={() => onInsertFormat('[ ] ', '', 'Task item')}
        className="p-1.5 rounded hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer"
      >
        <CheckSquare className="w-3.5 h-3.5" />
      </button>

      <div className="w-px h-4 bg-neutral-200 dark:bg-neutral-700 mx-1 shrink-0" />

      {/* Quotes & Code */}
      <button
        type="button"
        title="Quote"
        onClick={() => onInsertFormat('> ', '', 'Quoted thought')}
        className="p-1.5 rounded hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer"
      >
        <Quote className="w-3.5 h-3.5" />
      </button>

      <button
        type="button"
        title="Code Block"
        onClick={() => onInsertFormat('```\n', '\n```', 'code block')}
        className="p-1.5 rounded hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer"
      >
        <Code className="w-3.5 h-3.5" />
      </button>

      <div className="w-px h-4 bg-neutral-200 dark:bg-neutral-700 mx-1 shrink-0" />

      {/* Extras: Timestamp & Divider */}
      <button
        type="button"
        title="Insert Timestamp"
        onClick={onInsertTimestamp}
        className="p-1.5 rounded hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer"
      >
        <Calendar className="w-3.5 h-3.5" />
      </button>

      <button
        type="button"
        title="Horizontal Line (---)"
        onClick={() => onInsertFormat('\n---\n', '', '')}
        className="p-1.5 rounded hover:bg-black/5 dark:hover:bg-white/10 text-neutral-600 dark:text-neutral-300 transition-colors cursor-pointer"
      >
        <Minus className="w-3.5 h-3.5" />
      </button>

      {/* Clear Text button */}
      <div className="ml-auto pl-2">
        <button
          type="button"
          title="Clear Note Content"
          onClick={onClearContent}
          className="p-1.5 rounded hover:bg-red-500/10 text-neutral-400 hover:text-red-600 dark:hover:text-red-400 transition-colors cursor-pointer"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
