import React, { useRef, useEffect } from 'react';
import { Note, EditorSettings, NoteStats } from '../types';
import { FormatToolbar } from './FormatToolbar';

interface EditorProps {
  note: Note | null;
  settings: EditorSettings;
  stats: NoteStats;
  onUpdateNote: (updated: Partial<Note>) => void;
  onClearContent: () => void;
  onImportFile: (file: File) => void;
}

const CATEGORIES = ['General', 'Work', 'Ideas', 'To-Do', 'Draft'];

export const Editor: React.FC<EditorProps> = ({
  note,
  settings,
  stats,
  onUpdateNote,
  onClearContent,
  onImportFile,
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [isDragOver, setIsDragOver] = React.useState(false);

  // Auto-focus title if newly created empty note
  useEffect(() => {
    if (note && !note.title && !note.content && textareaRef.current) {
      // Focus textarea
      textareaRef.current.focus();
    }
  }, [note?.id]);

  if (!note) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 text-neutral-400">
        <p className="text-sm">Select a note or create a new one to begin writing.</p>
      </div>
    );
  }

  // Format insertion logic
  const handleInsertFormat = (prefix: string, suffix: string = '', defaultPlaceholder: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const currentText = note.content;
    const selectedText = currentText.substring(start, end);

    let replacement = '';
    let newCursorPos = start;

    if (selectedText) {
      replacement = `${prefix}${selectedText}${suffix}`;
      newCursorPos = start + replacement.length;
    } else {
      const placeholder = defaultPlaceholder || '';
      replacement = `${prefix}${placeholder}${suffix}`;
      newCursorPos = start + prefix.length + placeholder.length;
    }

    const newContent = currentText.substring(0, start) + replacement + currentText.substring(end);
    onUpdateNote({ content: newContent });

    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  };

  const handleInsertTimestamp = () => {
    const now = new Date();
    const stamp = `[${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}] `;
    handleInsertFormat(stamp, '');
  };

  // Keyboard shortcut & auto-continuation for lists
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    // Tab key indent
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const indent = '  '; // 2 spaces
      const newContent = note.content.substring(0, start) + indent + note.content.substring(end);
      onUpdateNote({ content: newContent });
      setTimeout(() => {
        textarea.setSelectionRange(start + indent.length, start + indent.length);
      }, 0);
      return;
    }

    // Ctrl+B / Cmd+B for bold
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b') {
      e.preventDefault();
      handleInsertFormat('**', '**', 'bold text');
      return;
    }

    // Ctrl+I / Cmd+I for italic
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'i') {
      e.preventDefault();
      handleInsertFormat('*', '*', 'italic text');
      return;
    }

    // Enter key smart list continuation
    if (e.key === 'Enter' && !e.shiftKey) {
      const start = textarea.selectionStart;
      const content = note.content;
      const lineStart = content.lastIndexOf('\n', start - 1) + 1;
      const currentLine = content.substring(lineStart, start);

      // Check bullet list: "- "
      const bulletMatch = currentLine.match(/^(\s*)-\s+(.*)$/);
      if (bulletMatch) {
        e.preventDefault();
        const indent = bulletMatch[1];
        const text = bulletMatch[2];
        if (text.trim() === '') {
          // Empty list item: exit list
          const newContent = content.substring(0, lineStart) + content.substring(start);
          onUpdateNote({ content: newContent });
          setTimeout(() => textarea.setSelectionRange(lineStart, lineStart), 0);
        } else {
          // Continue bullet list
          const insert = `\n${indent}- `;
          const newContent = content.substring(0, start) + insert + content.substring(start);
          onUpdateNote({ content: newContent });
          setTimeout(() => textarea.setSelectionRange(start + insert.length, start + insert.length), 0);
        }
        return;
      }

      // Check checklist: "[ ] " or "[x] "
      const checkMatch = currentLine.match(/^(\s*)\[([ xX])\]\s+(.*)$/);
      if (checkMatch) {
        e.preventDefault();
        const indent = checkMatch[1];
        const text = checkMatch[3];
        if (text.trim() === '') {
          // Empty checklist: clear and exit
          const newContent = content.substring(0, lineStart) + content.substring(start);
          onUpdateNote({ content: newContent });
          setTimeout(() => textarea.setSelectionRange(lineStart, lineStart), 0);
        } else {
          // Continue checklist
          const insert = `\n${indent}[ ] `;
          const newContent = content.substring(0, start) + insert + content.substring(start);
          onUpdateNote({ content: newContent });
          setTimeout(() => textarea.setSelectionRange(start + insert.length, start + insert.length), 0);
        }
        return;
      }

      // Check numbered list: "1. "
      const numMatch = currentLine.match(/^(\s*)(\d+)\.\s+(.*)$/);
      if (numMatch) {
        e.preventDefault();
        const indent = numMatch[1];
        const num = parseInt(numMatch[2], 10);
        const text = numMatch[3];
        if (text.trim() === '') {
          // Empty item: clear and exit
          const newContent = content.substring(0, lineStart) + content.substring(start);
          onUpdateNote({ content: newContent });
          setTimeout(() => textarea.setSelectionRange(lineStart, lineStart), 0);
        } else {
          // Continue numbered list
          const insert = `\n${indent}${num + 1}. `;
          const newContent = content.substring(0, start) + insert + content.substring(start);
          onUpdateNote({ content: newContent });
          setTimeout(() => textarea.setSelectionRange(start + insert.length, start + insert.length), 0);
        }
        return;
      }
    }
  };

  // Drag & drop file support
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      onImportFile(files[0]);
    }
  };

  // Font family resolution
  const getFontFamily = () => {
    switch (settings.fontFamily) {
      case 'serif':
        return 'var(--notepad-font-serif)';
      case 'mono':
        return 'var(--notepad-font-mono)';
      default:
        return 'var(--notepad-font-sans)';
    }
  };

  // Font size resolution
  const getFontSize = () => {
    switch (settings.fontSize) {
      case 'sm':
        return '14px';
      case 'lg':
        return '18px';
      case 'xl':
        return '20px';
      default:
        return '16px';
    }
  };

  // Paper texture class
  const getPaperClass = () => {
    if (settings.paperStyle === 'plain') return '';
    if (settings.paperStyle === 'lined') return `paper-lined-${settings.theme}`;
    if (settings.paperStyle === 'grid') return `paper-grid-${settings.theme}`;
    return '';
  };

  const lineCount = note.content.split('\n').length;
  const lineNumbersArray = Array.from({ length: lineCount }, (_, i) => i + 1);

  return (
    <div 
      id="notepad-editor-container"
      className="flex-1 flex flex-col h-full overflow-hidden relative"
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {/* Drag & drop overlay */}
      {isDragOver && (
        <div className="absolute inset-0 z-40 bg-amber-500/10 backdrop-blur-xs border-2 border-dashed border-amber-500 flex flex-col items-center justify-center pointer-events-none">
          <p className="text-base font-semibold text-amber-700 dark:text-amber-300">
            Drop text or markdown file to load
          </p>
        </div>
      )}

      {/* Format Toolbar */}
      <FormatToolbar
        onInsertFormat={handleInsertFormat}
        onClearContent={onClearContent}
        onInsertTimestamp={handleInsertTimestamp}
      />

      {/* Note Title & Category Header Area */}
      <div className="px-5 sm:px-8 pt-4 pb-2 border-b border-black/5 dark:border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shrink-0">
        <input
          id="note-title-input"
          type="text"
          placeholder="Note Title..."
          value={note.title}
          onChange={(e) => onUpdateNote({ title: e.target.value })}
          className="text-xl sm:text-2xl font-bold bg-transparent border-none outline-hidden placeholder:text-neutral-600 dark:placeholder:text-neutral-400 text-inherit w-full tracking-tight"
          style={{ fontFamily: getFontFamily() }}
        />

        {/* Category Pill selector */}
        <div className="flex items-center gap-1.5 shrink-0 self-start sm:self-center">
          <span className="text-[11px] text-neutral-600 dark:text-neutral-400 font-medium">Category:</span>
          <select
            id="note-category-select"
            value={note.category || 'General'}
            onChange={(e) => onUpdateNote({ category: e.target.value })}
            className="text-xs py-1 px-2 rounded-md bg-black/5 dark:bg-white/10 border-transparent focus:outline-hidden text-inherit font-medium cursor-pointer"
          >
            {CATEGORIES.map((cat) => (
              <option key={cat} value={cat} className="bg-white dark:bg-neutral-800 text-neutral-800 dark:text-neutral-100">
                {cat}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Editor Content Area */}
      <div className={`flex-1 flex overflow-hidden relative ${settings.theme === 'amber' ? 'legal-pad-margin ml-2 sm:ml-4' : ''}`}>
        {/* Line Numbers column */}
        {settings.lineNumbers && (
          <div 
            className="select-none py-4 px-2.5 text-right text-neutral-600 dark:text-neutral-400 text-xs font-mono opacity-50 shrink-0 border-r border-black/5 dark:border-white/5 overflow-hidden"
            style={{ 
              lineHeight: settings.paperStyle === 'lined' ? '32px' : '1.7',
              fontSize: getFontSize(),
            }}
          >
            {lineNumbersArray.map((num) => (
              <div key={num}>{num}</div>
            ))}
          </div>
        )}

        {/* Writing Textarea */}
        <div className="flex-1 h-full overflow-y-auto px-4 sm:px-8 py-4">
          <textarea
            ref={textareaRef}
            id="note-content-textarea"
            placeholder="Start typing your note here... (Markdown formatting and checklists supported)"
            value={note.content}
            onChange={(e) => onUpdateNote({ content: e.target.value })}
            onKeyDown={handleKeyDown}
            spellCheck={settings.spellCheck}
            className={`w-full min-h-full resize-none border-none outline-hidden bg-transparent ${getPaperClass()} text-inherit transition-all placeholder:text-neutral-600 dark:placeholder:text-neutral-400`}
            style={{
              fontFamily: getFontFamily(),
              fontSize: getFontSize(),
              lineHeight: settings.paperStyle === 'lined' ? '32px' : '1.7',
              whiteSpace: settings.wordWrap ? 'pre-wrap' : 'pre',
            }}
          />
        </div>
      </div>

      {/* Editor Stats Footer Bar */}
      <footer 
        id="notepad-stats-bar"
        className="h-8 border-t px-4 sm:px-8 flex items-center justify-between text-[11px] text-neutral-600 dark:text-neutral-400 select-none shrink-0"
      >
        <div className="flex items-center gap-3">
          <span>{stats.words.toLocaleString()} words</span>
          <span>•</span>
          <span>{stats.characters.toLocaleString()} chars</span>
          <span>•</span>
          <span>{stats.lines.toLocaleString()} lines</span>
        </div>

        <div className="flex items-center gap-2 font-medium">
          <span className="hidden sm:inline">~{stats.readingTimeMinutes} min read</span>
          <span>•</span>
          <span>{settings.paperStyle} paper</span>
        </div>
      </footer>
    </div>
  );
};
